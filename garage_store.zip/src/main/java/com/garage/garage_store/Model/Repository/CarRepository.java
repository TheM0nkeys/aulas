package com.garage.garage_store.Model.Repository;

import com.garage.garage_store.Model.Entity.Car;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CarRepository extends JpaRepository<Car,Integer> {

    boolean existsByCodigo(String codigo);

    boolean existsByCodigoAndIdNot(String codigo,Integer id);
}
